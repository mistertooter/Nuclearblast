"""Educational cinematic illustration, not a predictive effects model.
Requires Python 3, Pillow, NumPy and ffmpeg. Run: python render_nuclear_city.py
Scene times are editorial; no weapon yield, damage radii or dose predictions.
Sources: https://www.cdc.gov/radiation-emergencies/about/nuclear-blast-faq.html
https://remm.hhs.gov/nuclearfallout.htm
https://www.ready.gov/sites/default/files/2024-03/ready.gov_nuclear-explosion-hazard-info-sheet.pdf
"""
import math, random, subprocess
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
W,H,FPS,DURATION=1280,720,24,42
ROOT=Path(__file__).resolve().parent
rng=random.Random(49)
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
F=lambda n,b=False:ImageFont.truetype(bold if b else font,n)
buildings=[]
for row in range(4):
 x=-30
 while x<W:
  w=rng.randint(23,65); h=rng.randint(35,130)+row*14
  if abs(x-580)<100:h+=rng.randint(20,70)
  buildings.append((x,425+row*26,w,h,row,rng.random()))
  x+=w+rng.randint(5,15)
cloud=[(rng.uniform(-1,1),rng.uniform(-.65,.65),rng.uniform(18,48),rng.random()) for _ in range(100)]
particles=[(rng.random(),rng.random(),rng.random()) for _ in range(500)]
stages=[
 ('A CITY BEFORE THE FLASH','FICTIONAL CITY • ESTABLISHING VIEW',('A ground-level detonation is illustrated.','Effects and timing are compressed; distances are not to scale.')),
 ('01  FLASH & FIREBALL','FIRST MOMENTS',('Intense light and heat arrive before the blast wave.','Near the source: extreme destruction; prompt radiation is invisible.')),
 ('02  SHOCKWAVE','SECONDS LATER • LOCATION DEPENDENT',('Rapid pressure changes and powerful winds damage structures.','Flying glass and debris can injure people beyond collapsed buildings.')),
 ('03  FIRE & COLLAPSE','SECONDS TO MINUTES',('Heat can ignite materials; damaged buildings and utilities fuel fires.','Dust, smoke and rubble obstruct roads and emergency response.')),
 ('04  RADIOACTIVE FALLOUT','MINUTES TO HOURS • TIME JUMP',('A ground burst draws contaminated soil and debris into the cloud.','Wind carries particles downwind; radiation itself cannot be seen.')),
 ('05  THE AFTERMATH','HOURS TO YEARS • TIME JUMP',('Injuries, burns and disrupted water, power and medical care compound harm.','Radiation effects depend on dose; some cancer risks persist for years.'))]

def render(t):
 idx=0 if t<4 else 1 if t<10 else 2 if t<17 else 3 if t<24 else 4 if t<33 else 5
 a=max(0,t-4); shock=max(0,(t-9)*84)
 # Dark blue atmosphere with warm haze nearer the horizon.
 ar=np.zeros((H,W,3),dtype=np.uint8)
 for y in range(H):
  q=y/H; ar[y,:,:]=[int(7+20*q),int(15+24*q),int(29+28*q)]
 im=Image.fromarray(ar); d=ImageDraw.Draw(im)
 d.ellipse((-200,365,1500,1100),fill=(24,31,36))
 for i in range(15):
  xx=i*110-150; d.line((640,410,xx,595),fill=(42,48,49),width=2)
 for yy in [444,476,520,577]:d.line((0,yy,W,yy),fill=(46,48,46),width=2)
 # Evolving hot fireball, lit smoke and rising convection column.
 if a>0:
  glow=Image.new('RGBA',(W,H));g=ImageDraw.Draw(glow)
  rad=min(150,25+a*23) if a<6 else max(34,150-(a-6)*9)
  gy=407-min(140,a*9)
  for k in range(14,0,-1):
   rr=rad*(1+k*.13);g.ellipse((640-rr,gy-rr,640+rr,gy+rr),fill=(255,110,25,int(5+12*(1-k/15))))
  im=Image.alpha_composite(im.convert('RGBA'),glow.filter(ImageFilter.GaussianBlur(15)))
  d=ImageDraw.Draw(im)
  if a<12:
   for k in range(14,0,-1):
    rr=rad*k/14; c=(255,int(95+150*(1-k/14)),int(15+200*(1-k/14)))
    d.ellipse((640-rr,gy-rr,640+rr,gy+rr),fill=c)
  if a>3:
   smoke=Image.new('RGBA',(W,H)); s=ImageDraw.Draw(smoke)
   grow=min(1,(a-3)/13); top=350-grow*175
   for j in range(45):
    yy=440-j*4.5*grow; xx=640+math.sin(j*.71+t*.2)*16*grow
    r=12+grow*19+j*.25;s.ellipse((xx-r,yy-r,xx+r,yy+r),fill=(77+j,65+j//2,57,195))
   for xx,yy,r,z in cloud:
    cx=640+xx*190*grow+max(0,a-19)*5; cy=top+yy*70*grow
    rr=r*(.25+grow);light=int(37+z*48)
    s.ellipse((cx-rr,cy-rr*.7,cx+rr,cy+rr*.7),fill=(light+17,light+7,light,225))
   im=Image.alpha_composite(im,smoke.filter(ImageFilter.GaussianBlur(3)))
 d=ImageDraw.Draw(im)
 # Street-level architecture and progressive damage (art direction, not physics).
 for x,y,w,h,row,z in buildings:
  dist=abs(x+w/2-640); hit=t>9 and shock>dist
  damage=hit and dist<440 and z>.2
  hh=h*(.24 if damage else 1); c=(23+row*5,30+row*4,39+row*3)
  d.rectangle((x,y-hh,x+w,y),fill=c)
  d.polygon([(x+w,y-hh),(x+w+7,y-hh+6),(x+w+7,y),(x+w,y)],fill=(12,19,27))
  d.line((x,y-hh,x+w,y-hh),fill=(93,77,62) if a else (65,78,90),width=2)
  for wx in range(x+5,x+w-3,10):
   for wy in range(int(y-hh)+9,y-5,14):
    if not hit and (wx+wy)%7>2:d.rectangle((wx,wy,wx+3,wy+5),fill=(152,157,133))
  if damage:
   for j in range(5):
    xx=x+j*w/5; d.polygon([(xx,y),(xx+9,y-8-z*10),(xx+17,y)],fill=(55,53,49))
  if t>17 and hit and z>.56:
   for j in range(3):
    fx=x+w*(j+1)/4; fy=y-hh+4; fl=10+9*math.sin(t*6+j+x)
    d.polygon([(fx-6,fy),(fx-2,fy-fl),(fx+3,fy-fl*.6),(fx+6,fy)],fill=(247,112,27))
    d.polygon([(fx-3,fy),(fx,fy-fl*.7),(fx+3,fy)],fill=(255,210,90))
 if 9<t<20:
  # Thin ring visualizes the pressure front; it is not a visible wall of light.
  lay=Image.new('RGBA',(W,H)); s=ImageDraw.Draw(lay)
  for j in range(6):
   rr=shock+j*3;s.ellipse((640-rr,435-rr*.28,640+rr,435+rr*.28),outline=(210,220,216,100-j*13),width=2)
  im=Image.alpha_composite(im.convert('RGBA'),lay.filter(ImageFilter.GaussianBlur(2)))
 if t>12:
  haze=Image.new('RGBA',(W,H));s=ImageDraw.Draw(haze)
  for j in range(36):
   xx=640+math.sin(j*2.8)*min(650,(t-10)*42);yy=460+math.cos(j)*27;r=20+(t-12)*2
   s.ellipse((xx-r,yy-r*.4,xx+r,yy+r*.4),fill=(108,91,70,28))
  im=Image.alpha_composite(im.convert('RGBA'),haze.filter(ImageFilter.GaussianBlur(14)))
 if t>=24:
  d=ImageDraw.Draw(im)
  for px,py,pz in particles:
   xx=(px*W+(t-24)*(12+pz*18))%W;yy=(py*460+(t-24)*(18+pz*14))%480+100
   d.ellipse((xx,yy,xx+1+pz*2,yy+1+pz*2),fill=(167,150,120))
 # Controlled exposure bloom, no strobing.
 if 4<t<6:
  white=Image.new('RGBA',(W,H),(255,240,199,int(210*math.exp(-(t-4)*2))))
  im=Image.alpha_composite(im.convert('RGBA'),white)
 d=ImageDraw.Draw(im)
 d.rectangle((0,0,W,119),fill=(6,13,22));d.rectangle((0,575,W,H),fill=(6,13,22))
 title,sub,lines=stages[idx]
 d.text((44,19),'NUCLEAR DETONATION  /  EFFECTS ON A CITY',font=F(15,True),fill=(138,173,191))
 d.text((42,46),title,font=F(32,True),fill=(244,239,224))
 d.text((44,91),sub,font=F(14,True),fill=(235,171,103))
 d.text((44,594),lines[0],font=F(23),fill=(240,242,241))
 d.text((44,629),lines[1],font=F(21),fill=(191,208,215))
 d.text((44,681),'ILLUSTRATIVE • FICTIONAL CITY • NOT A DAMAGE OR RADIATION MODEL',font=F(13),fill=(128,151,164))
 d.text((1110,681),f'{int(t):02d} / 42 s',font=F(13),fill=(169,188,197))
 for j in range(6):
  x=44+j*200;d.rectangle((x,562,x+184,565),fill=(238,170,94) if j<=idx else (64,76,82))
 if idx==2:d.text((860,151),'PRESSURE FRONT',font=F(16,True),fill=(218,222,215));d.text((860,174),'Visualization overlay',font=F(13),fill=(163,179,187))
 if idx==4:d.text((860,151),'WIND →',font=F(19,True),fill=(231,203,158))
 return im.convert('RGB')

if __name__=='__main__':
 import sys
 if '--preview' in sys.argv:
  for t in [3,7,14,21,28,38]:render(t).save(ROOT/f'preview_{t}.jpg')
 else:
  p=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-an','-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(ROOT/'nuclear_city_effects.mp4')],stdin=subprocess.PIPE)
  for i in range(FPS*DURATION):
   p.stdin.write(render(i/FPS).tobytes())
   if i%(FPS*6)==0:print(f'Rendered {i/FPS:.0f}s',flush=True)
  p.stdin.close()
  if p.wait():raise RuntimeError('ffmpeg failed')
