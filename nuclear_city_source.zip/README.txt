NUCLEAR DETONATION: EFFECTS ON A CITY
42-second, 1280 x 720, 24 fps silent educational animation.

Sequence: city establishing view; flash and fireball; blast wave; fires and
collapse; downwind fallout; longer-term humanitarian consequences.

This is a cinematic, stylized illustration of a fictional ground-level burst,
not photorealistic footage or a validated simulation. The pressure-front ring
is a visual aid. Ionizing radiation is invisible. Dust particles shown in the
fallout scene do not represent measured radioactivity. Scene timings are
editorial; there are explicit jumps from seconds to hours and years.
Actual outcomes depend on yield, burst height, shielding, weather, terrain,
and construction. No specific city, weapon, dose or damage radius is modeled.
Immediate effects overlap; chapter order separates them for explanation.

SOURCE CODE
Install Python 3, Pillow and NumPy; install ffmpeg on your system PATH.
  python -m pip install pillow numpy
  python render_nuclear_city.py
The script uses DejaVu Sans from Linux. Change font and bold paths if needed.
  python render_nuclear_city.py --preview
creates six still frames for review. Video has no soundtrack or narration.

SCIENTIFIC BACKGROUND
CDC, Nuclear Blasts: Frequently Asked Questions
https://www.cdc.gov/radiation-emergencies/about/nuclear-blast-faq.html
HHS REMM, Fallout from a Nuclear Detonation
https://remm.hhs.gov/nuclearfallout.htm
Ready.gov, Nuclear Explosion Hazard Information Sheet
https://www.ready.gov/sites/default/files/2024-03/ready.gov_nuclear-explosion-hazard-info-sheet.pdf

The initial heat, blast and radiation can cause severe injury and death.
Fallout is particulate contamination carried by wind; it is distinct from
prompt radiation. Health effects depend on received dose and exposure.
The last scene emphasizes infrastructure damage and longer-term risk rather
than suggesting that illness or death is inevitable for all survivors.
